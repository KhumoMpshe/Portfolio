rootProject.name = "ImageProcessor"

